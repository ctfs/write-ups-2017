from vgame.protocol import *
import utils

@protocol('LOGIN')
def LoginMessage(uname, passw):
    return {'username': uname, 'password': utils.hashPassword(passw)}

@protocol('SERVER_UPDATE')
def ServerUpdateMessage(player, mapView, serverState):
    hlth = (player.life.health, player.life.maxHealth)
    invt = []
    for i in player.inventory:
        invt.append(i.dump(player))
    shop = player.server.getMap(player.pos).isShop(player.pos)
    return {'state': serverState,
            'position': player.pos,
            'health': hlth,
            'level': player.creature.level,
            'xp': player.creature.xp,
            'shop': shop,
            'inventory': invt,
            'equipment': player.creature.dumpEquipment(player),
            'gold': player.creature.gold,
            'log': player.log,
            'map': mapView}

@protocol('MOVE')
def MoveMessage(mvmt, stateID):
    return {'state': stateID, 'move': mvmt}

@protocol('USE')
def UseMessage(item, target, stateID):
    return {'state': stateID, 'item': item, 'target': target}

@protocol('DROP')
def DropMessage(item, stateID):
    return {'state': stateID, 'item': item}

@protocol('DEATH')
def DeathMessage(msg):
    return {'message': msg}

@protocol('CHAT')
def ChatMessage(name, msg):
    return {'name': name, 'message': msg}
    
