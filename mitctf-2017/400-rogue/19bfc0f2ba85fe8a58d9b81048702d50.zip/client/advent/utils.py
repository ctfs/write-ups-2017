from vgame.utils import *

import constants

def randomItem(d):
    x = random.randint(1, sum([max(0, i) for i in d.values()])) - 1
    total = 0
    for k,v in d.iteritems():
        total += max(0, v)
        if x <= total:
            return k

def nextPosition(pos, move):
    if move == constants.MOVE_LEFT:
        return [pos[0], pos[1] - 1, pos[2]]
    elif move == constants.MOVE_RIGHT:
        return [pos[0], pos[1] + 1, pos[2]]
    elif move == constants.MOVE_UP:
        return [pos[0] - 1, pos[1], pos[2]]
    elif move == constants.MOVE_DOWN:
        return [pos[0] + 1, pos[1], pos[2]]
    return pos

def centerText(surface, font, color, text, y):
    x = (surface.get_width() - font.size(text)[0]) / 2
    surface.blit(font.render(text, 1, color), (x, y))

def getClosestEnemy(e, r):
    mp = e.server.getMap(e.pos)
    closest = None
    for y in range(-r, r+1):
        for x in range(-r, r+1):
            entities = mp.getEntities(offset(e.pos, [y,x]))
            for m in entities:
                if m != e and m.life:
                    if not closest or distance(e.pos, m.pos) < distance(e.pos, closest.pos):
                        closest = m
    return closest
