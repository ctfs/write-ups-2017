import pygame as pg
from vgame.state import State

from advent import assets
from advent import constants
from advent import utils

class GameOverState(State):
    def __init__(self, clt, msg):
        super(GameOverState, self).__init__(clt)
        self.restartGame = False
        self.reason = msg

    def nextState(self):
        if self.restartGame:
            self.restartGame = False
            return self.client.initialState
        return None

    def update(self, gui):
        if gui.keys[pg.K_r]:
            self.restartGame = True

    def render(self, surface):
        font = pg.font.Font(assets.FONTS['DroidSans'], 32)
        utils.centerText(surface, font, constants.COLORS['red'], 'You have died!', surface.get_height() / 2 - 50)
        utils.centerText(surface, font, constants.COLORS['red'], self.reason, surface.get_height() / 2)
        utils.centerText(surface, font, constants.COLORS['blue'], 'Press R to restart.', surface.get_height() / 2 + 50)
