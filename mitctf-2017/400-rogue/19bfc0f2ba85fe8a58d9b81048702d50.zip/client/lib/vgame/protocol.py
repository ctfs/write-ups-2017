import json

import utils

MESSAGE_END = "####****####"

def ValidMessage(m):
    try:
        ParseMessage(m)
    except Exception, e:
        print 'Invalid Message'
        return False
    return True

def ParseMessage(m):
    ps = []
    for msg in m.split(MESSAGE_END):
        if not msg.strip():
            continue
        while msg.startswith('\x00'):
            msg = msg[1:]
        if not msg.strip():
            continue
        ps.append(json.loads(msg))
    return ps

TYPES = {}

def MessageType(d):
    if 'type' in d and d['type'] in TYPES:
        return TYPES[d['type']]

def protocol(t):
    def real_protocol(f):
        def proto(*args, **kwargs):
            data = f(*args, **kwargs)
            data['type'] = t
            return json.dumps(data)
        TYPES[t] = proto
        return proto
    return real_protocol

@protocol('ERROR')
def ErrorMessage(msg):
    return {'msg': msg}
