import base64
import hashlib
import select
import socket
import sys
import time

from ws4py import websocket

BUFSIZE = 512

class NetworkServer(object):
    newClientHandler = None
    killClientHandler = None
    serverMessageHandler = None
    clientMessageHandler = None
    errorHandler = None

    def __init__(self, port, headless=False):
        self.port = port
        self.headless = headless
        self.clients = {}
        self.dead = []
        self.server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    def getClient(self, sock):
        for client,fd in self.clients.iteritems():
            if fd == sock:
                return client
        sock.close()
        try:
            self.fds.remove(sock)
        except:
            pass
        return None

    def killClient(self, clt):
        if clt in self.clients:
            sock = self.clients[clt]
            sock.close()
            try:
                self.fds.remove(sock)
            except:
                pass
            self.clients[clt] = None
            del self.clients[clt]
        if self.killClientHandler:
            self.killClientHandler(clt)

    def sendSocket(self, sock, msg):
        try:
            sock.sendall(msg + '\x00')
        except Exception, e:
            if self.errorHandler:
                self.errorHandler(e)
            self.dead.append(self.getClient(sock))

    def recvSocket(self, sock):
        try:
            msg = sock.recv(BUFSIZE)
            if len(msg) == 0:
                self.dead.append(self.getClient(sock))
                return
            t0 = time.time()
            while msg[-1] != '\x00':
                if time.time() - t0 > 1:
                    self.dead.append(self.getClient(sock))
                    return
                msg += sock.recv(BUFSIZE)
            msg = msg[:-1]
            if msg and self.clientMessageHandler:
                clt = self.getClient(sock)
                self.clientMessageHandler(clt, msg)
        except Exception, e:
            if self.errorHandler:
                self.errorHandler(e)
            self.dead.append(self.getClient(sock))

    def handleNewClient(self, addr, fd):
        fd.setblocking(False)
        self.clients[self.newClientHandler(addr)] = fd


    def setup(self, gs):
        self.newClientHandler = gs.handleNewClient
        self.killClientHandler = gs.handleKillClient
        if not self.headless:
            self.serverMessageHandler = gs.handleServerMessage
        self.clientMessageHandler = gs.handleClientMessage
        self.errorHandler = gs.handleNetworkError
        return self

    def start(self):
        self.server_sock.bind(("0.0.0.0", self.port))
        self.server_sock.listen(16)
        if self.headless:
            self.fds = [self.server_sock]
        else:
            self.fds = [self.server_sock, sys.stdin]

    def tick(self, timeout=0):
        if timeout < 0:
            timeout = 0
        for c in self.dead:
            self.killClient(c)
        self.dead = []

        read_fds, write_fds, err_fds = select.select(self.fds, [], [], timeout)
        for sock in read_fds:
            if sock == self.server_sock:
                new_fd, addr = sock.accept()
                self.fds.append(new_fd)
                if self.newClientHandler:
                    self.handleNewClient(addr, new_fd)
            elif sock == sys.stdin:
                if self.serverMessageHandler:
                    self.serverMessageHandler(sys.stdin.readline())
            else:
                self.recvSocket(sock)

    def shutdown(self):
        self.server_sock.close()

    def run(self):
        self.start()
        while True:
            try:
                self.tick(None)
            except:
                break
        self.shutdown()

    def broadcast(self, msg, ignore_clients=None):
        ignore_socks = []
        if ignore_clients:
            for clt in ignore_clients:
                ignore_socks.append(self.clients[clt])
        ignore_socks += [self.server_sock, sys.stdin]
        for sock in self.fds:
            if sock not in ignore_socks:
                self.sendSocket(sock, msg)

    def send(self, client, msg):
        if client in self.clients:
            self.sendSocket(self.clients[client], msg)

class NetworkClient(object):
    serverMessageHandler = None
    errorHandler = None

    def __init__(self, host, port, ws=False):
        self.host = host
        self.port = port
        self.ws = ws
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    def recvSocket(self, sock):
        try:
            msg = sock.recv(BUFSIZE)
            t0 = time.time()
            while msg[-1] != '\x00':
                if time.time() - t0 > 1:
                    return
                msg += sock.recv(BUFSIZE)
            msg = msg[:-1]
            if msg and self.serverMessageHandler:
                self.serverMessageHandler(msg)
        except Exception, e:
            if self.errorHandler:
                self.errorHandler(e)

    def sendSocket(self, msg):
        try:
            self.socket.sendall(msg + '\x00')
        except Exception, e:
            if self.errorHandler:
                self.errorHandler(e)

    def setup(self, gc):
        self.serverMessageHandler = gc.handleServerMessage
        self.errorHandler = gc.handleNetworkError
        return self

    def start(self):
        try:
            self.socket.connect((self.host, self.port))
            if self.ws:
                self.socket.sendall('\x00')
        except Exception, e:
            if self.errorHandler:
                self.errorHandler(e)
        self.fds = [self.socket]

    def tick(self, timeout=0):
        read_fds, write_fds, err_fds = select.select(self.fds, [], [], timeout)
        for sock in read_fds:
            self.recvSocket(sock)

    def shutdown(self):
        self.socket.close()

    def restart(self):
        self.shutdown()
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.start()

    def run(self):
        self.start()
        while True:
            try:
                self.tick(None)
            except:
                break
        self.shutdown()

    def send(self, msg):
        self.sendSocket(msg)


def wsHandshake(client):
    def createHash(key):
        plain = key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11'
        return base64.b64encode(hashlib.sha1(plain).digest())  
 
    def parseHeaders(data):
        headers = {}
        for l in data.splitlines():
            parts = l.split(": ", 1)
            if len(parts) == 2:
                headers[parts[0]] = parts[1]
        return headers
 
    data = client.recv(1024)
    if 'GET /' not in data:
        return False
    headers = parseHeaders(data)
    digest = createHash(headers['Sec-WebSocket-Key'])
    shake = "HTTP/1.1 101 Web Socket Protocol Handshake\r\n"
    shake += "Upgrade: WebSocket\r\n" 
    shake += "Connection: Upgrade\r\n"
    shake += "Sec-WebSocket-Origin: %s\r\n" % (headers['Origin'])
    shake += "Sec-WebSocket-Location: ws://%s/stuff\r\n" % (headers['Host'])
    shake += "Sec-WebSocket-Accept: %s\r\n\r\n" % (digest)
    client.sendall(shake)
    return True

class NetworkWSServer(NetworkServer):
    def __init__(self, port, headless=False):
        super(NetworkWSServer, self).__init__(port, headless)
        self.ws = {}

    def killClient(self, clt):
        if clt in self.clients:
            sock = self.clients[clt]
            if sock in self.ws:
                self.ws[sock].close()
                del self.ws[sock]
        super(NetworkWSServer, self).killClient(clt)

    def sendSocket(self, sock, msg):
        try:
            if sock in self.ws:
                self.ws[sock].send(msg)
            else:
                super(NetworkWSServer, self).sendSocket(sock, msg)
        except Exception, e:
            if self.errorHandler:
                self.errorHandler(e)
            self.dead.append(self.getClient(sock))

    def recvSocket(self, sock):
        try:
            if sock in self.ws:
                self.ws[sock].msgHandler = self.clientMessageHandler
                self.ws[sock].msgClient = self.getClient(sock)
                self.ws[sock].once()
            else:
                super(NetworkWSServer, self).recvSocket(sock)
        except Exception, e:
            if self.errorHandler:
                self.errorHandler(e)
            self.dead.append(self.getClient(sock))

    def handleNewClient(self, addr, fd):
        if wsHandshake(fd):
            self.ws[fd] = NetworkWSClient(fd)
        else:
            fd.setblocking(False)
        self.clients[self.newClientHandler(addr)] = fd

class NetworkWSClient(websocket.WebSocket):
    def __init__(self, fd):
        websocket.WebSocket.__init__(self, fd)
 
    def received_message(self, msg):
        if msg and self.msgHandler:
            clt = self.msgClient
            self.msgHandler(clt, msg)

class NOPNetworkClient(NetworkClient):
    def __init__(self):
        self.socket = True

    def setup(self, gc):
        return self

    def start(self):
        pass
    
    def tick(self, timeout=0):
        pass
    
    def shutdown(self):
        pass

    def restart(self):
        pass
