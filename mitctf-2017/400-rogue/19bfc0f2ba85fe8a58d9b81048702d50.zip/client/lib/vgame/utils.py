import hashlib
import math
import random

def hashPassword(p):
    return hashlib.sha256(p).hexdigest()
    h = sha.new()
    h.update(p)
    return h.hexdigest()

def bound(x, lower, upper):
    return max(min(x, upper), lower)

def randomElement(l):
    return l[random.randint(0, len(l) - 1)]

def distance(p1, p2):
    return math.sqrt(sum([pow(p2[i] - p1[i], 2) for i in range(len(p1))]))

def randomID():
    return '%08x' % random.randint(0, 2**32-1)

def offset(p, o):
    return [p[i]+o[i] if i < len(o) else p[i] for i in range(len(p))]

def inBox(p, box):
    dim = len(p)
    for d in range(dim):
        if not (box[d] < p[d] < box[d] + box[dim + d]):
            return False
    return True
