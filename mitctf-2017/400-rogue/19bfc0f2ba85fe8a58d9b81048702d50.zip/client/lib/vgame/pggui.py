import pygame as pg
from vgame.gui import BaseGUI

class BasePGGUI(BaseGUI):
    def __init__(self, clt, title, wsize):
        super(BasePGGUI, self).__init__(clt, title)
        self.wsize = wsize
        
    def setup(self):
        pg.display.set_caption(self.title)
        self.window = pg.display.set_mode(self.wsize)
        self.window = pg.display.set_mode(self.wsize, pg.RESIZABLE)
        self.canvas = self.window.get_rect()
        self.keys = pg.key.get_pressed()
        self.mouse = pg.mouse.get_pos() + pg.mouse.get_pressed()
        self.letter = None

    def updateEvents(self):
        for event in pg.event.get():
            if event.type == pg.QUIT:
                self.client.done = True
            elif event.type == pg.VIDEORESIZE:
                self.wsize = event.size
                self.window = pg.display.set_mode(self.wsize, pg.RESIZABLE)
                self.canvas = self.window.get_rect()
            elif event.type in (pg.KEYDOWN, pg.KEYUP):
                self.keys = pg.key.get_pressed()
                if event.type == pg.KEYDOWN:
                    self.letter = event.unicode
                else:
                    self.letter = None
            elif event.type in (pg.MOUSEMOTION, pg.MOUSEBUTTONDOWN, pg.MOUSEBUTTONUP):
                self.mouse = pg.mouse.get_pos() + pg.mouse.get_pressed()

    def render(self, screen):
        self.window.blit(screen, (0, 0), (0, 0, self.wsize[0], self.wsize[1]))
        pg.display.update()

def PGGUI(title, wsize):
    def gui(clt):
        return BasePGGUI(clt, title, wsize)
    return gui
