class BaseServerClient(object):
    def __init__(self, addr, srvr):
        self.address = addr
        self.server = srvr

    def __str__(self):
        return 'CLIENT<%s:%d>' % self.address

    def handle(self, prots):
        for prot in prots:
            self.handleMessage(prot)

    def handleMessage(self, prot):
        pass
    
    def logout(self):
        pass
    
