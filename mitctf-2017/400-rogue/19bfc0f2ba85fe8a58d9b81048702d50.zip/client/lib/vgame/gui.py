class BaseGUI(object):
    def __init__(self, clt, title):
        self.client = clt
        self.title = title

    def setup(self):
        pass

    def updateEvents(self):
        pass

    def render(self, screen):
        pass
