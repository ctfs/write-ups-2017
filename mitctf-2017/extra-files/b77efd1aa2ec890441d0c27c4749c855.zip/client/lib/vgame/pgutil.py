import os
import pygame as pg

def centerText(surface, font, color, text, y, margin=0, width=None):
    if not width:
        width = surface.get_width() - margin
    x = (width - font.size(text)[0]) / 2
    surface.blit(font.render(text, 1, color), (margin + x, y))

def load(directory, accept, convertFunc=lambda x:x):
    assets = {}
    for fn in os.listdir(directory):
        full = os.path.join(directory, fn)
        if os.path.isdir(full):
            sub = load(full, accept, convertFunc)
            for k,v in sub.iteritems():
                assets[os.path.join(fn, k)] = v
        else:
            name,ext = os.path.splitext(fn)
            if ext.lower().replace('.', '') in accept:
                assets[name] = convertFunc(full)
    return assets

def convertImage(fn):
    img = pg.image.load(fn)
    if img.get_alpha():
        return img.convert_alpha()
    else:
        return img.convert()

def getImage(sheet, x, y, w, h):
    img = pg.Surface([w, h])
    rect = img.get_rect()
    img.blit(sheet, (0, 0), (x, y, w, h))
    img.set_colorkey(pg.color.THECOLORS['black'])
    return img
