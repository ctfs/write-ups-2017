import argparse
import json
import sys
import time
import traceback

from protocol import *
from sclient import BaseServerClient

class BaseServer(object):
    def __init__(self, ns, Client=BaseServerClient, fps=30):
        self.Client = Client
        self.fps = fps
        self.network = ns.setup(self)
        self.running = True
        self.clients = []
        self.debug = False
        
    def broadcast(self, msg, ignore_clients=None):
        if self.debug:
            print '[BROADCAST] %s' % msg
        self.network.broadcast(msg, ignore_clients)

    def sendMessage(self, clt, msg):
        if self.debug:
            print '[-> %s] %s' % (clt, msg)
        if not isinstance(msg, str):
            msg = json.dumps(msg)
        self.network.send(clt, msg + MESSAGE_END)

    def handleNewClient(self, addr):
        if self.debug:
            print '%s connected' % addr[0]
        clt = self.Client(addr, self)
        self.clients.append(clt)
        return clt

    def handleKillClient(self, clt):
        if self.debug:
            print '%s disconnected' % clt
        clt.logout()
        self.clients.remove(clt)

    def handleNetworkError(self, err):
        if self.debug:
            traceback.print_exc()
        pass

    def handleServerMessage(self, msg):
        if self.debug:
            print '[SERVER] %s' % msg

    def handleClientMessage(self, clt, msg):
        if self.debug:
            print '[%s] %s' % (clt, msg.split(MESSAGE_END))
        if ValidMessage(msg):
            clt.handle(ParseMessage(msg))

    def killClient(self, clt):
        self.sendMessage(clt, ErrorMessage('Disconnected'))
        self.network.dead.append(clt)

    def begin(self):
        pass

    def end(self):
        pass

    def step(self):
        pass

    def run(self):
        self.network.start()
        self.lastTick = time.time()
        self.begin()
        while self.running:
            now = time.time()
            if now - self.lastTick > 1.0/self.fps:
                self.lastTick = now
                self.network.tick()
                self.step()
            else:
                self.network.tick(0.9 * (1.0/self.fps - (now - self.lastTick)))
        self.end()


def server_parser(name, port):
    parser = argparse.ArgumentParser(description='Run the %s server.' % (name))
    parser.add_argument('--host', dest='host', default='0.0.0.0', help='The host to listen to.')
    parser.add_argument('-p', '--port', dest='port', type=int, default=port, help='The port that clients connect to.')
    parser.add_argument('-H', dest='headless', action='store_const', const=True, default=False, help='Whether to ignore STDIN')
    return parser
