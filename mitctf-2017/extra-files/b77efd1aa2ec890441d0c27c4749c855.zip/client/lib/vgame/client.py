import argparse
import json
import time

import protocol
from state import StateManager

class BaseClient(object):
    def __init__(self, ns, GUI, fps=30):
        self.network = ns.setup(self)
        self.gui = GUI(self)
        self.fps = fps
        self.done = False
        self.debug = False
        self.init()

    def sendMessage(self, msg):
        if self.debug:
            print '[-> SERVER] %s' % msg
        if type(msg) is not str:
            msg = json.dumps(msg)
        self.network.send(msg + protocol.MESSAGE_END)

    def handleNetworkError(self, err):
        if self.debug:
            print err
        self.done = True

    def handleProtocolMessage(self, proto):
        pass

    def handleServerMessage(self, msg):
        if protocol.ValidMessage(msg):
            for proto in protocol.ParseMessage(msg):
                self.handleProtocolMessage(proto)
        else:
            self.handleNetworkError('Invalid Protocol Message: %s' % msg)

    def init(self):
        pass

    def begin(self):
        pass

    def end(self):
        pass

    def step(self):
        pass

    def run(self):
        self.network.start()
        self.gui.setup()
        self.lastTick = time.time()
        self.begin()
        while not self.done:
            if not self.network.socket:
                self.done = True
                break
            now = time.time()
            if now - self.lastTick > 1.0/self.fps:
                self.lastTick = now
                self.network.tick()
                self.gui.updateEvents()
                self.step()
            else:
                self.network.tick(0.9 * (1.0/self.fps - (now - self.lastTick)))
        self.network.shutdown()
        self.end()

class SMClient(BaseClient):
    def __init__(self, ns, GUI, fps, Initial):
        super(SMClient, self).__init__(ns, GUI, fps)
        self.initialState = Initial(self)
        self.sm = StateManager(self.initialState)

    def handleNetworkError(self, err):
        self.done = self.sm.handleNetworkError(err)

    def handleProtocolMessage(self, proto):
        self.sm.handleServerMessage(proto)

    def begin(self):
        self.sm.setup()

    def draw(self):
        pass

    def step(self):
        self.sm.update(self.gui)
        screen = self.surface()
        self.sm.render(screen)
        self.gui.render(screen)



def client_parser(name, port):
    parser = argparse.ArgumentParser(description='Run the %s client.' % (name))
    parser.add_argument('--host', dest='host', default='127.0.0.1', help='The host to connect to.')
    parser.add_argument('-p', '--port', dest='port', type=int, default=port, help='The port that clients connect to.')
    return parser

