class State(object):
    def __init__(self, clt):
        self.client = clt

    def enterState(self):
        pass

    def leaveState(self):
        pass

    def nextState(self):
        return None

    def handleNetworkError(self, err):
        return False

    def handleServerMessage(self, msg):
        pass

    def update(self, gui):
        pass

    def render(self, screen):
        pass

class StateManager:
    current = None

    def __init__(self, initState):
        self.current = initState

    def setup(self):
        self.handleNetworkError = self.current.handleNetworkError
        self.handleServerMessage = self.current.handleServerMessage
        self.render = self.current.render
        self.current.enterState()

    def handleNetworkError(self, err):
        pass

    def handleServerMessage(self, msg):
        pass
        
    def update(self, gui):
        self.current.update(gui)
        ns = self.current.nextState()
        if ns:
            self.current.leaveState()
            self.current = ns
            self.setup()
