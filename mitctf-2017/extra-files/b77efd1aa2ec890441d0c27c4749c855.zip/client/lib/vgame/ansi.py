# -*- coding: utf-8 -*-

ESC = "\033["

def moveTo(row, col):
    return ESC + str(row + 1) + ";" + str(col + 1) + "H"

def up(n):
    return ESC + str(n) + "A"

def down(n):
    return ESC + str(n) + "B"

def left(n):
    return ESC + str(n) + "D"

def right(n):
    return ESC + str(n) + "C"

def save():
    return ESC + "s"

def load():
    return ESC + "u"

def clear():
    return ESC + "2J"

def clearline():
    return ESC + "K"

def format(args, t=None):
    if t:
        return ESC + ";".join(args) + "m" + t + reset()
    return ESC + ";".join(args) + "m"

def reset():
    return ESC + "0;0m"

NORMAL = "0"
BOLD = "1"
UNDERLINE = "4"
BLINK = "5"
REVERSE = "7"
INVISIBLE = "8"
F_BLACK = "30"
F_RED = "31"
F_GREEN = "32"
F_YELLOW = "33"
F_BLUE = "34"
F_MAGENTA = "35"
F_CYAN = "36"
F_WHITE = "37"
B_BLACK = "40"
B_RED = "41"
B_GREEN = "42"
B_YELLOW = "43"
B_BLUE = "44"
B_MAGENTA = "45"
B_CYAN = "46"
B_WHITE = "47"

COLOR_RGB = [
    (0, 0, 0),
    (255, 0, 0), 
    (0, 255, 0),
    (255, 255, 0), 
    (0, 0, 255), 
    (255, 0, 255),
    (0, 255, 255),
    (255, 255, 255), 
]

def closestColor(c):
    closest = (0, pow(2, 32))
    
    for i in range(len(COLOR_RGB)):
        (r,g,b) = COLOR_RGB[i]
        dist = pow(c[0] - r, 2) + pow(c[1] - g, 2) + pow(c[2] - b, 2)
        if dist < closest[1]:
            closest = (i, dist)
    return str(30 + closest[0])


L_TL = "┌"
L_H = "─"
L_TR = "┐"
L_V = "│"
L_BL = "└"
L_BR = "┘"
L_BRKL = "├"
L_BRKR = "┤"

def screen(w, h):
    t = moveTo(0,0) + L_TL
    for i in range(w):
        t += L_H
    t += L_TR

    for i in range(1, h+1):
        t += moveTo(i, 0) + L_V
        t += moveTo(i, w + 1) + L_V

    t += moveTo(h + 1, 0) + L_BL
    for i in range(w):
        t += L_H
    t += L_BR

    t += moveTo(0,0)
    return t

def clearRow(r, l):
    t = moveTo(r, 1)
    for i in range(l):
        t += " "
    return t

def drawBreak(l):
    t = L_BRKL
    for i in range(l):
        t += L_H
    t += L_BRKR
    return t

#─━│┃┄┅┆┇┈┉┊┋┌┍┎┏┐┑┒┓
#└┕┖┗┘┙┚┛├┝┞┟┠┡┢┣┤┥┦┧
#┨┩┪┫┬┭┮┯┰┱┲┳┴┵┶┷┸┹┺┻
#┼┽┾┿╀╁╂╃╄╅╆╇╈╉╊╋╌╍╎╏
#═║╒╓╔╕╖╗╘╙╚╛╜╝╞╟╠╡╢╣╤╥
#╦╧╨╩╪╫╬╭╮╯╰╱╲╳╴╵╶╷╸╹
#╺╻╼╽╾╿
