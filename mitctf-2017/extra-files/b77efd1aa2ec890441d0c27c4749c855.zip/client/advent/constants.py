import pygame as pg

GAME_NAME = 'ROGUE'
DEFAULT_PORT = 4242
FPS = 30
SERVER_FPS = 10

WIDTH = 1024
HEIGHT = 768
TILESIZE = 16
SCALE = 2

VISIBILITY = 32

COLORS = pg.color.THECOLORS

MOVE_NONE = -1
MOVE_DOWN = 1
MOVE_LEFT = 2
MOVE_RIGHT = 3
MOVE_UP = 4
MOVE_INTERACT_DOWN = 5
MOVE_INTERACT_LEFT = 6
MOVE_INTERACT_RIGHT = 7
MOVE_INTERACT_UP = 8
MOVE_INTERACT_HERE = 9
MOVE_UPWARD = 10
MOVE_DOWNWARD = 11
MOVE_LEVEL_A = 51
MOVE_LEVEL_B = 52
MOVE_LEVEL_C = 53

DIFF_EASY = 5
DIFF_NORMAL = 10
DIFF_HARD = 20

PLAYER_HP = 200
PLAYER_REGEN = 2

DEFEND_ATTACK = False

SPAWN_MAP = 0

XP_LEVEL_FACTOR = 100

PLAYER_IMAGE = ['PCs/Civilian']

CARDINAL = [(-1, +0), (+0, +1), (+1, +0), (+0, -1)]

FLAMMABLE = 'Flammable'
STRUCTURAL = 'Structural'

ATTACK_OFFSETS = [
    (-2, -2), (-2, -1), (-2, +0), (-2, +1), (-2, +2),
    (-1, -2), (-1, -1), (-1, +0), (-1, +1), (-1, +2),
    (+0, -2), (+0, -1), (+0, +0), (+0, +1), (+0, +2),
    (+1, -2), (+1, -1), (+1, +0), (+1, +1), (+1, +2),
    (+2, -2), (+2, -1), (+2, +0), (+2, +1), (+2, +2),
]

SLOT_DICTIONARY = {1: 'HEAD', 2: 'BODY', 3: 'LEGS', 4: 'FEET', 5: 'HAND', 6: 'RING'}
