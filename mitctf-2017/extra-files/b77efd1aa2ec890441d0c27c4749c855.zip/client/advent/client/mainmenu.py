import pygame as pg
from vgame.pgutil import centerText
from vgame.state import State

from advent import assets
from advent import constants
from adventure import AdventureState

class MainMenuState(State):
    def __init__(self, clt):
        super(MainMenuState, self).__init__(clt)
        self.startGame = False
        self.username = 'alice'
        self.password = '123'
        self.selected = 0
        self.lastLetter = 0

    def nextState(self):
        if self.startGame:
            self.startGame = False
            return AdventureState(self.client, self.username, self.password)
        return None

    def update(self, gui):
        if gui.keys[pg.K_RETURN]:
            self.startGame = True
        elif gui.letter != self.lastLetter:
            self.lastLetter = gui.letter
            if self.lastLetter == '\t':
                self.selected = 1 - self.selected
            elif self.lastLetter == '\b':
                if self.selected == 0:
                    self.username = self.username[:-1]
                else:
                    self.password = self.password[:-1]
            elif self.lastLetter:
                if self.selected == 0:
                    self.username += self.lastLetter
                else:
                    self.password += self.lastLetter


    def render(self, surface):
        font = pg.font.Font(assets.FONTS['DroidSans'], 32)
        centerText(surface, font, constants.COLORS['blue'], 'The Forsaken', surface.get_height() / 2 - 200)
        surface.blit(font.render('Username:', 1, constants.COLORS['red']), ((240 - font.size('Username:')[0]), surface.get_height() / 2 - 100))
        surface.blit(font.render('Password:', 1, constants.COLORS['red']), ((240 - font.size('Password:')[0]), surface.get_height() / 2 - 25))
        if self.selected == 0:
            pg.draw.rect(surface, constants.COLORS['white'], (250, surface.get_height() / 2 - 100, surface.get_width() - 400, font.size('A')[1]), 1)
        else:
            pg.draw.rect(surface, constants.COLORS['white'], (250, surface.get_height() / 2 - 25, surface.get_width() - 400, font.size('A')[1]), 1)
        surface.blit(font.render(self.username, 1, constants.COLORS['white']), (250, surface.get_height() / 2 - 100))
        surface.blit(font.render(self.password, 1, constants.COLORS['white']), (250, surface.get_height() / 2 - 25))

        centerText(surface, font, constants.COLORS['blue'], 'Press TAB to switch between fields.', surface.get_height() / 2 + 100)
        centerText(surface, font, constants.COLORS['blue'], 'Press ENTER to continue.', surface.get_height() / 2 + 150)
        centerText(surface, font, constants.COLORS['blue'], 'The Flag lies 10 below.', surface.get_height() / 2 + 200)
