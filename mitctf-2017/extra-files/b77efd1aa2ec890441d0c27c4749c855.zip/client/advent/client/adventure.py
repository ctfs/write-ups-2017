import math
import pygame as pg
import textwrap
import time
from vgame.state import State

from advent import assets
from advent import constants
from advent.protocol import *
from advent import utils
from gameover import GameOverState

class AdventureState(State):
    def __init__(self, clt, uname, passw):
        super(AdventureState, self).__init__(clt)
        self.username = uname
        self.password = passw
        self.lastTick = pg.time.get_ticks()
        self.position = None
        self.mapView = None
        self.health = 100
        self.maxHealth = 100
        self.move = constants.MOVE_NONE
        self.gold = 0
        self.dead = None
        self.log = []
        self.inventory = []
        self.equipment = {}
        self.selectedTile = None
        self.selectedItem = None
        self.activeTile = None
        self.activeItem = None
        self.serverState = -1
        self.lastMove = 0
        self.lastActiveMove = 0
        self.chatMessage = None
        self.lastChatLetter = None
        self.level = 1
        self.xp = 0
        self.inventoryPos = [0, 0]
        self.equipmentPos = [0, 0]
        self.inShop = False
        self.sentState = -1
        self.recvState = -1

    def nextState(self):
        if self.dead:
            return GameOverState(self.client, self.dead)
        return None

    def enterState(self):
        self.client.network.restart()
        un = self.username
        pw = self.password
        self.client.sendMessage(LoginMessage(un, pw))

    def handleServerMessage(self, msg):
        if MessageType(msg) == ServerUpdateMessage:
            self.lastTick = pg.time.get_ticks()
            self.position = msg['position']
            self.mapView = msg['map']
            self.health = msg['health'][0]
            self.maxHealth = msg['health'][1]
            self.gold = msg['gold']
            self.level = msg['level']
            self.xp = msg['xp']
            self.log = msg['log']
            self.inShop = msg['shop']
            self.inventory = msg['inventory']
            self.equipment = msg['equipment']
            self.serverState = msg['state']
            if self.recvState < self.sentState:
                self.sentState = self.serverState
                self.client.sendMessage(MoveMessage(self.move, self.serverState))
            else:
                self.move = constants.MOVE_NONE
        elif MessageType(msg) == ErrorMessage:
            print '[ERROR] %s' % msg['message']
            self.client.done = True
        elif MessageType(msg) == DeathMessage:
            print '[DEATH] %s' % msg['message']
            self.dead = msg['message']
        elif 'state' in msg:
            if msg['state'] > self.recvState:
                self.recvState = msg['state']

    def update(self, gui):
        self.gui = gui
        if not self.mapView:
            return
        move = None
        usedReturn = False

        CVH2 = len(self.mapView) / 2
        CVW2 = len(self.mapView[0]) / 2

        if self.chatMessage != None:
            if gui.keys[pg.K_RETURN]:
                if self.chatMessage:
                    self.client.sendMessage(ChatMessage(self.username, self.chatMessage))
                self.chatMessage = None
                usedReturn = True
            elif gui.letter != self.lastChatLetter:
                self.lastChatLetter = gui.letter
                if self.lastChatLetter == '\b':
                    self.chatMessage = self.chatMessage[:-1]
                elif self.lastChatLetter and self.lastChatLetter != '\t':
                    self.chatMessage += self.lastChatLetter
        else:
            activeMove = None
            if gui.keys[pg.K_TAB]:
                self.chatMessage = ''
                self.lastChatLetter = gui.letter
            if gui.keys[pg.K_w] or gui.keys[pg.K_UP] or gui.keys[pg.K_KP8]:
                move = constants.MOVE_UP
            if gui.keys[pg.K_s] or gui.keys[pg.K_DOWN] or gui.keys[pg.K_KP2]:
                move = constants.MOVE_DOWN
            if gui.keys[pg.K_a] or gui.keys[pg.K_LEFT] or gui.keys[pg.K_KP4]:
                move = constants.MOVE_LEFT
            if gui.keys[pg.K_d] or gui.keys[pg.K_RIGHT] or gui.keys[pg.K_KP6]:
                move = constants.MOVE_RIGHT
            if gui.keys[pg.K_c] or gui.keys[pg.K_SPACE] or gui.keys[pg.K_KP5]:
                move = constants.MOVE_NONE
            if gui.keys[pg.K_o]:
                if gui.keys[pg.K_LSHIFT]:
                    activeMove = constants.MOVE_NONE
                else:
                    move = constants.MOVE_INTERACT_HERE
            if gui.keys[pg.K_i]:
                if gui.keys[pg.K_LSHIFT]:
                    activeMove = constants.MOVE_UP
                else:
                    move = constants.MOVE_INTERACT_UP
            if gui.keys[pg.K_k]:
                if gui.keys[pg.K_LSHIFT]:
                    activeMove = constants.MOVE_DOWN
                else:
                    move = constants.MOVE_INTERACT_DOWN
            if gui.keys[pg.K_j]:
                if gui.keys[pg.K_LSHIFT]:
                    activeMove = constants.MOVE_LEFT
                else:
                    move = constants.MOVE_INTERACT_LEFT
            if gui.keys[pg.K_l]:
                if gui.keys[pg.K_LSHIFT]:
                    activeMove = constants.MOVE_RIGHT
                else:
                    move = constants.MOVE_INTERACT_RIGHT
            if gui.keys[pg.K_LESS] or gui.keys[pg.K_COMMA]:
                move = constants.MOVE_UPWARD
            if gui.keys[pg.K_GREATER] or gui.keys[pg.K_PERIOD]:
                move = constants.MOVE_DOWNWARD
            if gui.keys[pg.K_v]:
                move = constants.MOVE_LEVEL_A
            if gui.keys[pg.K_b]:
                move = constants.MOVE_LEVEL_B
            if gui.keys[pg.K_n]:
                move = constants.MOVE_LEVEL_C

            if self.activeItem != None and 0 <= self.activeItem < len(self.inventory) and gui.keys[pg.K_LSHIFT] and activeMove and time.time() - self.lastActiveMove > 0.25:
                self.lastActiveMove = time.time()
                if not self.activeTile or activeMove == constants.MOVE_NONE:
                    self.activeTile = [CVH2, CVW2]
                newActiveTile = utils.nextPosition(self.activeTile + [0], activeMove)[:2]
                dist = utils.distance([CVH2, CVW2], newActiveTile)
                if dist <= self.inventory[self.activeItem]['item_range']:
                    self.activeTile = newActiveTile

        self.selectedTile = None
        self.selectedItem = None

        ts = constants.SCALE*constants.TILESIZE

        topLeft = [(gui.wsize[1] - ts) / 2 - CVH2*ts, (gui.wsize[0] - ts) / 2 - CVW2*ts]
        tileCoords = [(gui.mouse[1] - topLeft[0]) / ts, (gui.mouse[0] - topLeft[1]) / ts]

        if tileCoords[0] >= 0 and tileCoords[0] < len(self.mapView) and tileCoords[1] >= 0 and tileCoords[1] < len(self.mapView[0]):
            self.selectedTile = tileCoords


        topLeft = self.inventoryPos
        itemsInRow = min(int(gui.wsize[0]/2 - 4) / ts, 8)
        itemCoords = [(gui.mouse[1] - topLeft[0]) / ts, (gui.mouse[0] - topLeft[1]) / ts]

        if itemCoords[0] >= 0 and itemCoords[1] >= 0 and itemCoords[1] < itemsInRow:
            itemNum = itemCoords[0] * itemsInRow + itemCoords[1]
            if 0 <= itemNum < len(self.inventory):
                self.selectedItem = itemNum
            self.selectedTile = None

        topLeft = self.equipmentPos
        equipmentCoords = [(gui.mouse[1] - topLeft[0]) / ts, (gui.mouse[0] - topLeft[1]) / ts]
        if equipmentCoords[1] == 0 and equipmentCoords[0] < len(constants.SLOT_DICTIONARY.keys()):
            self.selectedItem = -1 - equipmentCoords[0]

        if self.selectedTile and gui.mouse[2] and not move:
            if self.selectedTile == [CVH2-1, CVW2]:
                move = constants.MOVE_INTERACT_UP
            if self.selectedTile == [CVH2+1, CVW2]:
                move = constants.MOVE_INTERACT_DOWN
            if self.selectedTile == [CVH2, CVW2-1]:
                move = constants.MOVE_INTERACT_LEFT
            if self.selectedTile == [CVH2, CVW2+1]:
                move = constants.MOVE_INTERACT_RIGHT
        if self.selectedTile and gui.mouse[4] and not move:
            if self.selectedTile == [CVH2-1, CVW2]:
                move = constants.MOVE_UP
            if self.selectedTile == [CVH2+1, CVW2]:
                move = constants.MOVE_DOWN
            if self.selectedTile == [CVH2, CVW2-1]:
                move = constants.MOVE_LEFT
            if self.selectedTile == [CVH2, CVW2+1]:
                move = constants.MOVE_RIGHT

        itemNum = -1
        if self.chatMessage == None:
            if gui.keys[pg.K_1]: itemNum = 0
            if gui.keys[pg.K_2]: itemNum = 1
            if gui.keys[pg.K_3]: itemNum = 2
            if gui.keys[pg.K_4]: itemNum = 3
            if gui.keys[pg.K_5]: itemNum = 4
            if gui.keys[pg.K_6]: itemNum = 5
            if gui.keys[pg.K_7]: itemNum = 6
            if gui.keys[pg.K_8]: itemNum = 7
            if gui.keys[pg.K_9]: itemNum = 8
            if gui.keys[pg.K_0]: itemNum = 9
        if 0 <= itemNum < len(self.inventory):
            self.activeItem = itemNum

        if gui.mouse[4]:
            self.activeItem = None
            self.activeTile = None
        elif self.selectedItem != None and gui.mouse[2]:
            self.activeItem = self.selectedItem
        elif self.selectedTile != None and self.activeItem != None and 0 <= self.activeItem < len(self.inventory) and gui.mouse[2]:
            dist = utils.distance([CVH2, CVW2], self.selectedTile)
            if dist <= self.inventory[self.activeItem]['item_range']:
                self.activeTile = self.selectedTile
            move = None
        elif gui.mouse[2]:
            self.activeItem = None
            self.activeTile = None
        if time.time() - self.lastMove > 0.25:
            self.lastMove = time.time()
            if self.activeItem != None and 0 <= self.activeItem < len(self.inventory) and self.chatMessage == None and gui.keys[pg.K_RETURN]:
                if usedReturn:
                    return
                target = [0, 0]
                if self.activeTile:
                    target = [self.activeTile[0] - CVH2, self.activeTile[1] - CVW2]
                if self.inventory[self.activeItem]['uses'] == 1:
                    self.activeItem = None
                self.client.sendMessage(UseMessage(self.activeItem, target, self.serverState))
                self.activeTile = None
            elif self.activeItem != None and self.chatMessage == None and gui.keys[pg.K_BACKSPACE]:
                self.client.sendMessage(DropMessage(self.activeItem, self.serverState))
                self.activeTile = None
                self.activeItem = None
            elif self.selectedItem and self.selectedItem < 0 and gui.mouse[4]:
                self.client.sendMessage(DropMessage(self.selectedItem, self.serverState))
                self.activeTile = None
                self.activeItem = None
            elif move and move != self.move:
                self.move = move
                self.sentState = self.serverState
                self.client.sendMessage(MoveMessage(self.move, self.serverState))
            else:
                self.lastMove = 0


    def drawMap(self, surface):
        if not self.mapView:
            return

        CVH = len(self.mapView) / 2 * 2
        CVH2 = CVH / 2
        CVW = len(self.mapView[0]) / 2 * 2
        CVW2 = CVW / 2
        ts = constants.SCALE*constants.TILESIZE
        center = [(surface.get_height()-ts)/2, (surface.get_width()-ts)/2]
        mapFrame = (center[1]-CVW2*ts, center[0]-CVH2*ts,
                    (CVW+1)*ts, (CVH+1)*ts)
        pg.draw.rect(surface, constants.COLORS['brown'], mapFrame, 1)
        for y in range(len(self.mapView)):
            for x in range(len(self.mapView[y])):
                ty = center[0]+(y - CVH2)*ts
                tx = center[1]+(x - CVW2)*ts
                tordered = []
                for t in self.mapView[y][x]:
                    if not t:
                        continue
                    if 'draw_order' in t:
                        tordered.append((t['draw_order'], t))
                    else:
                        tordered.append((-1, t))
                tordered = sorted(tordered)
                for (_, t) in tordered:
                    img = None
                    if t['kind'] == 'Player' and x == CVW2 and y == CVH2:
                        img = assets.getEntity(t['image'], (pg.time.get_ticks() / 250) % 4 if 5 > self.move > 0 else 0, (max(0, self.move - 1) % 4) if self.move < 10 else 0)
                    else:
                        img = assets.getAnimatedEntity(t['image'], time=pg.time.get_ticks())
                    if img:
                        surface.blit(img, (tx, ty))
                    if t['kind'] == 'Player' or t['kind'] == 'Enemy':
                        pg.draw.rect(surface, constants.COLORS['red'], (tx, ty+ts-8, ts, 8), 0)
                        pg.draw.rect(surface, constants.COLORS['green'], (tx, ty+ts-8, max(0, int(ts * t['health'])), 8), 0)
                if utils.nextPosition(self.position, self.move) == [y + self.position[0] - CVH2, x + self.position[1] - CVW2, self.position[2]]:
                    pg.draw.rect(surface, constants.COLORS['blue'], (tx,ty,ts,ts), 2)
                if [y, x] == self.activeTile:
                    pg.draw.rect(surface, constants.COLORS['red'], (tx,ty,ts,ts), 2)

        return surface

    def drawUI(self, surface):
        # Timer
        time = pg.time.get_ticks() - self.lastTick
        n = int(min(max(360 * (1 - time / (1000.0 / constants.SERVER_FPS)), 1), 360))
        cx, cy, r = 50, 50, 40
        pg.draw.circle(surface, constants.COLORS['white'], (cx, cy), r)
        ps = [(cx, cy)]
        for i in range(0, n):
            x = cx + int((r+1) * math.cos((i-90) * math.pi/180))
            y = cy + int((r+1) * math.sin((i-90) * math.pi/180))
            ps.append((x, y))
        ps.append((cx, cy))
        pg.draw.polygon(surface, constants.COLORS['red'], ps)

        Y = int(0.75 * surface.get_height())
        X = 2
        font = pg.font.Font(assets.FONTS['DroidSans'], 16)

        pg.draw.rect(surface, constants.COLORS['blue'], (X, Y, surface.get_width() - X - 2, surface.get_height() - Y - 2), 0)

        # Health
        X += 4
        msg = 'Health:'
        surface.blit(font.render(msg, 1, constants.COLORS['white']), (X, Y))
        X += font.size(msg)[0] + 4
        healthFrac = 1.0 * self.health / self.maxHealth
        pg.draw.rect(surface, constants.COLORS['red'], (X, Y+2, 200, 14), 0)
        pg.draw.rect(surface, constants.COLORS['green'], (X, Y+2, max(0, int(200*healthFrac)), 14), 0)
        healthText = '%d / %d' % (self.health, self.maxHealth)
        x = X + max(0, int(100*healthFrac) - font.size(healthText)[0] / 2)
        surface.blit(font.render(healthText, 1, constants.COLORS['black']), (x, Y))
        X = surface.get_width() / 2 + 6

        # Gold
        msg = 'Gold: %d' % self.gold
        surface.blit(font.render(msg, 1, constants.COLORS['gold']), (X, Y))
        X += font.size(msg)[0] + surface.get_width() / 16

        # Shop?
        if self.inShop:
            msg = 'Shopping!'
            msg2 = 'Drop Item=Sell, Pickup Item=Buy'
            x = 16
            y = Y - 40
            pg.draw.rect(surface, constants.COLORS['gray'], (x, y, font.size(msg2)[0] + 4, 36), 0)
            surface.blit(font.render(msg, 1, constants.COLORS['black']), (x + 2, y))
            surface.blit(font.render(msg2, 1, constants.COLORS['black']), (x + 2, y + 18))

        # Character Level / XP
        if self.xp >= constants.XP_LEVEL_FACTOR * self.level:
            msg = 'New Level Available:'
            msg2 = 'V=+Health, B=+Strength, N=+Defense'
            x = surface.get_width() - (font.size(msg2)[0] + 16)
            y = Y - 40
            pg.draw.rect(surface, constants.COLORS['gray'], (x, y, font.size(msg2)[0] + 4, 36), 0)
            surface.blit(font.render(msg, 1, constants.COLORS['black']), (x + 2, y))
            surface.blit(font.render(msg2, 1, constants.COLORS['black']), (x + 2, y + 18))

        msg = 'Level: %d (%d / %d)' % (self.level, self.xp, constants.XP_LEVEL_FACTOR * self.level)
        surface.blit(font.render(msg, 1, constants.COLORS['green']), (X, Y))
        X += font.size(msg)[0] + surface.get_width() / 16

        # Dungeon Level
        if self.position:
            msg = 'Floor: %d' % self.position[2]
            surface.blit(font.render(msg, 1, constants.COLORS['purple']), (X, Y))

        X = 2
        Y += 20

        # Log
        LOG_HEIGHT = surface.get_height() - Y - 28
        LOG_WIDTH = surface.get_width() / 2 - 4
        TEXT_HEIGHT = 12
        NUM_LINES = (LOG_HEIGHT - 8) / (TEXT_HEIGHT + 2)
        LINE_LENGTH = int(2.25 * (LOG_WIDTH - 16) / TEXT_HEIGHT)

        pg.draw.rect(surface, constants.COLORS['blue'], (X, Y, LOG_WIDTH, LOG_HEIGHT), 0)
        pg.draw.rect(surface, constants.COLORS['black'], (X + 2, Y + 2, LOG_WIDTH - 4, LOG_HEIGHT - 4), 1)

        font = pg.font.Font(assets.FONTS['DroidSans'], TEXT_HEIGHT)
        newLog = []
        lastSize = 1
        for l in self.log:
            newLog += textwrap.wrap(l, LINE_LENGTH)
            lastSize = len(textwrap.wrap(l, LINE_LENGTH))

        y = Y + ((NUM_LINES - 1) * (TEXT_HEIGHT + 2)) + 2
        for i in range(1, NUM_LINES+1):
            if i > len(newLog):
                break
            surface.blit(font.render(newLog[-i], 1, constants.COLORS['white']), (X + 8, y))
            y -= TEXT_HEIGHT + 2

        X += LOG_WIDTH + 2 + 2

        # Inventory
        INV_HEIGHT = LOG_HEIGHT
        INV_WIDTH = LOG_WIDTH
        ITEM_SIZE = constants.TILESIZE * constants.SCALE
        ITEMS_IN_ROW = min(INV_WIDTH / ITEM_SIZE, 8)
        NUM_LINES = (INV_HEIGHT - 8) / (TEXT_HEIGHT + 2)
        LINE_LENGTH = int(2.25 * (INV_WIDTH - 16) / TEXT_HEIGHT)

        pg.draw.rect(surface, constants.COLORS['blue'], (X, Y, INV_WIDTH, INV_HEIGHT), 0)
        pg.draw.rect(surface, constants.COLORS['black'], (X + 2, Y + 2, INV_WIDTH - 4, INV_HEIGHT - 4), 1)

        self.inventoryPos = [Y + 4, X + 5]

        font = pg.font.Font(assets.FONTS['DroidSans'], TEXT_HEIGHT)
        ts = ITEM_SIZE
        for i in range(len(self.inventory)):
            row = i / ITEMS_IN_ROW
            col = i % ITEMS_IN_ROW
            ty = self.inventoryPos[0] + row * ts
            tx = self.inventoryPos[1] + col * ts
            img = assets.getAnimatedEntity(self.inventory[i]['image'], time=pg.time.get_ticks())
            if img:
                surface.blit(img, (tx, ty))
            if 'uses' in self.inventory[i]:
                usage = 1.0 * self.inventory[i]['uses'][0] / self.inventory[i]['uses'][1]
                if usage != 1:
                    pg.draw.rect(surface, constants.COLORS['red'], (tx, ty+ts-4, ts, 4), 0)
                    pg.draw.rect(surface, constants.COLORS['green'], (tx, ty+ts-4, max(0, int(ts * usage)), 4), 0)

            if i == self.activeItem:
                pg.draw.rect(surface, constants.COLORS['red'], (tx, ty, ts, ts), 2)

        # Equipment
        font = pg.font.Font(assets.FONTS['DroidSans'], 16)
        twidth = font.size('XXXX:')[0]
        X = surface.get_width() - twidth - 16 - ts
        y = 4
        thoff = (ts - 16) / 2
        self.equipmentPos = [y, X + twidth + 4]

        pg.draw.rect(surface, constants.COLORS['blue'], (X - 6, y, twidth + 16 + ts, ts * 6 + 8), 0)

        for slot in constants.SLOT_DICTIONARY.values():
            if slot in self.equipment and self.equipment[slot]:
                tx, ty = (X + twidth + 4, y)
                item = self.equipment[slot]
                img = assets.getAnimatedEntity(item['image'], time=pg.time.get_ticks())
                surface.blit(img, (tx, ty))
                if self.activeItem and self.activeItem < 0:
                    if -self.activeItem in constants.SLOT_DICTIONARY and constants.SLOT_DICTIONARY[-self.activeItem] == slot:
                        pg.draw.rect(surface, constants.COLORS['red'], (tx, ty, ts, ts), 2)
            surface.blit(font.render(slot.title() + ':', 1, constants.COLORS['black']), (X, y+thoff))
            y += ts

        # Chats
        X = 4
        Y += LOG_HEIGHT + 4
        msg = 'Chat:'
        surface.blit(font.render(msg, 1, constants.COLORS['white']), (X, Y))
        X += font.size(msg)[0] + 4
        if self.chatMessage != None:
            pg.draw.rect(surface, constants.COLORS['gray'], (X, Y, surface.get_width() - 2 - 4 - X, 18), 0)
            surface.blit(font.render(self.chatMessage, 1, constants.COLORS['black']), (X + 1, Y))


        # Examine
        if self.selectedTile and self.mapView:
            things = self.mapView[self.selectedTile[0]][self.selectedTile[1]]
            if things:
                thing = None
                tordered = []
                for t in things:
                    if not t:
                        continue
                    if 'draw_order' in t:
                        tordered.append((t['draw_order'], t))
                    else:
                        tordered.append((-1, t))
                tordered = sorted(tordered)
                for (_, t) in tordered:
                    if 'name' in t and t['name'] != self.username:
                        thing = t
                if thing:
                    x = self.gui.mouse[0]
                    y = self.gui.mouse[1]
                    n = thing['name']
                    if self.inShop and 'value' in thing:
                        n += " (%d Gold)" % thing['value']
                    if x > surface.get_width() / 2:
                        x -= 1 + font.size(n)[0]
                    else:
                        x += 1 + 8
                    if y > surface.get_height() / 2:
                        y -= 1 + font.size(n)[1]
                    else:
                        y += 1 + 8
                    surface.blit(font.render(n, 1, constants.COLORS['white']), (x, y))


        if self.selectedItem != None:
            item = None
            if 0 <= self.selectedItem < len(self.inventory):
                item = self.inventory[self.selectedItem]
            elif self.selectedItem < 0 and -self.selectedItem in constants.SLOT_DICTIONARY:
                slot = constants.SLOT_DICTIONARY[-self.selectedItem]
                item = self.equipment[slot]

            if item:
                x = self.gui.mouse[0]
                y = self.gui.mouse[1]
                n = item['name']
                if self.inShop and 'value' in item:
                    n += " (%d Gold)" % (item['value'] / 2)
                if x > surface.get_width() / 2:
                    x -= 1 + font.size(n)[0]
                else:
                    x += 1 + 8
                if y > surface.get_height() / 2:
                    y -= 1 + font.size(n)[1]
                else:
                    y += 1 + 8
                surface.blit(font.render(n, 1, constants.COLORS['white']), (x, y))

    def render(self, surface):
        self.drawMap(surface)
        self.drawUI(surface)
