#!/usr/bin/python
import math
import os
import sys
import time
import pygame as pg
from vgame.client import SMClient, client_parser
from vgame.network import NetworkClient
from vgame.pggui import PGGUI

os.environ['SDL_VIDEO_CENTERED'] = '1'
pg.init()

import assets
import constants
import protocol
import utils
from client.mainmenu import MainMenuState

class GameClient(SMClient):
    def __init__(self, ns):
        super(GameClient, self).__init__(ns, PGGUI(constants.GAME_NAME, (constants.WIDTH, constants.HEIGHT)), constants.FPS, MainMenuState)

    def begin(self):
        super(GameClient, self).begin()
        assets.setup()

    def end(self):
        pg.quit()

    def surface(self):
        return pg.Surface(self.gui.wsize)

def run():
    parser = client_parser(constants.GAME_NAME, constants.DEFAULT_PORT)
    args = parser.parse_args()
    GameClient(NetworkClient(args.host, args.port)).run()

if __name__ == "__main__":
    run()
