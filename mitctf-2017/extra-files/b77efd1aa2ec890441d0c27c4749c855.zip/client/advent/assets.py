import os
import pygame as pg
from vgame.pgutil import *

import constants

FONTS = load(os.path.join('resources', 'fonts'), ('ttf'))

def setup():
    pass

def animatedGraphics(fn, t):
    if (t / 500) % 2 == 0 and fn.endswith('0') and 'Door' not in fn:
        return fn[:-1] + '1'
    return fn

IMAGES = {
    'Objects/Floor': ['.', 'gray'],
    'Objects/Wall': ['#', 'white'],
    'Objects/Door0': ['X', 'white'],
    'Objects/Door1': ['X', 'green'],
    'Items/Money': ['$', 'gold'],
    'Items/Scroll': ['s', 'blue'],
    'Items/Wand': ['!', 'green'],
    'Items/Ammo': ['o', 'red'],
    'Items/Potion': ['p', 'purple'],
    'PCs/Civilian': ['*', 'yellow'],
    'Objects/Ground0': ['.', 'white'],
    'Objects/Ground1': ['.', 'red'],
    'Characters/Humanoid0': ['H', 'red'],
    'Characters/Humanoid1': ['H', 'red'],
    'Characters/Pest0': ['R', 'red'],
    'Characters/Pest1': ['R', 'red'],
    'Characters/Demon0': ['D', 'red'],
    'Characters/Demon1': ['D', 'red'],
}

def getEntity(img, offx=None, offy=None):
    font = pg.font.Font(FONTS['DroidSans'], constants.TILESIZE * constants.SCALE)
    fn = img[0]
    if img[0] == 'TINT':
        ts = constants.TILESIZE * constants.SCALE
        surface = pg.Surface([ts, ts])
        surface.set_alpha(190)
        return surface
    elif fn in IMAGES:
        img = font.render(IMAGES[fn][0], 1, constants.COLORS[IMAGES[fn][1]])
        ts = constants.TILESIZE * constants.SCALE
        surface = pg.Surface([ts, ts])
        sz = font.size(IMAGES[fn][0])
        surface.blit(img, ((ts - sz[0])/2, (ts - sz[1])/2))
        return surface
    else:
        print fn
        return font.render('?', 1, constants.COLORS['white'])

def getAnimatedEntity(img, time=0, offx=None, offy=None):
    img = img[:]
    img[0] = animatedGraphics(img[0], time)
    return getEntity(img, offx=offx, offy=offy)
