import json
import socket

from util import *

STORES = {}

def getStore(pub):
    k = ':'.join(str(i) for i in pub)
    if k not in STORES:
        STORES[k] = {}
    return STORES[k]

def handle(msg):
    data = json.loads(msg)
    ret = []
    if len(data) == 3:
        store = getStore(data[1])
        if data[0] == 1:
            nonce = generateSecret(64)
            store[nonce] = FROM(data[2])
            ret = [nonce]
        elif data[0] == 2:
            ret = [fs_encrypt(n, data[1]) for n in store.keys()]
        elif data[0] == 3:
            try:
                ret = [store[FROM(data[2])]]
            except:
                pass
    return json.dumps([TO(i) for i in ret])

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
sock.bind(('0.0.0.0', 5555))
sock.listen(16)
while True:
    conn, addr = sock.accept()
    print 'Got', addr
    conn.settimeout(1)
    try:
        conn.sendall(handle(conn.recv(4096)))
        conn.close()
    except:
        pass
