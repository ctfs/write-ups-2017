#!/usr/bin/python
import hmac
import json
import socket
import sys
from Crypto.Cipher import AES

from util import *

ops = {
    'STORE': 1,
    'LIST': 2,
    'GET': 3,
}

flags = open('flag').read().split('\n')
FLAG_1 = flags[0]
FLAG_2 = flags[1]
FLAG_3 = flags[2]

def rinput(msg):
  print msg,
  return sys.stdin.readline().strip()

def handle(msg):
  sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  sock.connect(('localhost', 5555))
  sock.sendall(msg)
  return sock.recv(4096)

def call(type, pub, a2='\x00'):
  data = json.dumps([ops[type], pub, TO(a2)])
  return [FROM(i) for i in json.loads(handle(data))]

def handleUser():
  op = rinput('OP>')
  if op not in ops:
    print 'ERROR'
    return None
  pub = []
  try:
    pub = [int(i) for i in rinput('KEY>')[1:-2].split('L, ')]
  except:
    print 'ERROR'
    return None
  arg = '\x00'
  if op != 'LIST':
    arg = rinput('DATA>').decode('base64')
  return call(op, pub, arg)

def HMAC(k, n):
  assert(len(n) == 8)
  h = hmac.new(k)
  h.update(n)
  return h.digest()

def msg_encrypt(msg, mk):
  (epoch, key) = mk
  msgKey = HMAC(key, chr(epoch % 256) + 'MSG_KEY')
  raw = msg
  while len(raw) % 16 != 0:
    raw = '\x00' + raw
  cipher = AES.new(msgKey, AES.MODE_CBC, '\x00'*16)
  return cipher.encrypt(raw)

def keyUpdate(m0, args):
  (data, vdata) = args
  ne = m0[0] + 1
  nk = m0[1]
  verifier = None
  try:
    nk = HMAC(nk, data)
  except:
    pass
  
  verifier = HMAC(nk, 'V' + vdata)
  m1 = (ne, nk)
  return (m1, verifier)

def run():
  (mpub, mpriv) = generateFS()
  (cpub, cpriv) = generateFS()
  master = (0, generateSecret(64))
  call('STORE', cpub, '1:' + FLAG_1)
  call('STORE', cpub, '2:' + msg_encrypt(FLAG_2, master))
  print 'Client: %s\nServer: %s' % (cpub, mpub)
  prev = []
  while True:
    print handleUser()
    now = call('LIST', mpub)
    for en in now:
      if en not in prev:
        n = fs_decrypt(en, mpriv)
        data = call('GET', mpub, n)[0]
        if data[0] == '3':
          (master, verifier) = keyUpdate(master, data.split(':', 3)[1:])
          print 'VERIFIER:', verifier.encode('hex')
        call('STORE', cpub, '2:' + msg_encrypt(FLAG_3, master))
    prev = now

run()
