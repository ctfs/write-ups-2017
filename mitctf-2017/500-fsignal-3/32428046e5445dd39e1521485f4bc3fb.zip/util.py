import math
import random

def egcd(a, b):
    if a == 0:
        return (b, 0, 1)
    else:
        g, y, x = egcd(b % a, a)
        return (g, x - (b // a) * y, y)

def generateFS(N=64):
    w = [1]
    for i in range(N):
        t = sum(w)
        w.append(random.randint(t+1, 2*t))
    q = w[-1]
    w = w[:-1]
    r = random.randint(2, q-1)
    while egcd(q, r)[0] != 1:
        r = random.randint(2, q-1)
    b = [(r*i)%q for i in w]
    return (b, (w,q,r))

def fs_encrypt(plain, key):
    assert len(plain) == 8
    c = 0
    for i in range(8):
        l = format(ord(plain[i]), '#010b')[2:]
        for j in range(8):
            if l[j] == '1':
                c += key[8*i+j]
    return str(c)

def fs_decrypt(enc, key):
    (w, q, r) = key
    s = egcd(r, q)[1] % q
    c = (s*int(enc)) % q
    o = ''
    for i in range(len(w)):
        if w[-1-i] <= c:
          o += '1'
          c -= w[-1-i]
        else:
            o += '0'
    return ('%08x' % (int(o[::-1], 2))).decode('hex')

def FROM(m):
	hs = '%x' % m
	if len(hs) % 2 == 1:
		hs = '0' + hs
	return hs.decode('hex')

def TO(m):
	return int(m.encode('hex'), 16)

def generateSecret(len):
	return FROM(random.randint(0, 2**len))
